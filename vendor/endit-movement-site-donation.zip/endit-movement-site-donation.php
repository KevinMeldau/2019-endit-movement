<?php
/**
 * @package END_IT_Movement_Site_Donation
 * @version 1.0
 */
/*
Plugin Name: END IT Movement Site Donation
Plugin URI: 
Description: Let's raise a voice for the 27,000,000 trapped in slavery around the world.
Author: Polar Notion
Version: 1.0
Author URI: http://polarnotion.com
*/
wp_enqueue_script("jquery");

add_action('wp_footer','endit_movement_script');
function endit_movement_script()
{
echo "<script src='//d3olvfeqbqmgvm.cloudfront.net/endit-takeover/takeover.js'></script>";
}
?>
